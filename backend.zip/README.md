# Milandin BestellFix Backend (src-Version)

Backend für Artikelnummern → Google Sheet. Leg deine JSON-Datei hier rein.